import { createSlice } from "@reduxjs/toolkit";
import { readAllUser, addNewUser, editUser, deleteUser } from '../Action/UserAction'


const userSlice = createSlice({
    name: "user",
    initialState: [],
    extraReducers: (builder) => {
        builder.addCase(addNewUser.fulfilled, (state, action) => { })
            .addCase(readAllUser.fulfilled, (state, action) => {
                return [...action.payload]
            })
            .addCase(editUser.fulfilled, (state, action) => { })
            .addCase(deleteUser.fulfilled, (state, action) => { })
    }
})

export default userSlice